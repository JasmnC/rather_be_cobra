import React, { useState } from "react";

export default function FunctionPanel({ selectedFunc }) {
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  if (!selectedFunc) {
    return (
      <div className="h-full flex items-center justify-center text-gray-500">
        Select a function from the left to start
      </div>
    );
  }

  async function run() {
    setError(null);
    setResult(null);
    try {
      // allow functions to be sync or async
      const out = await Promise.resolve(selectedFunc.fn(input));
      setResult(out);
    } catch (e) {
      setError(String(e));
    }
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{selectedFunc.label}</h2>

      <label className="block mb-2">Input</label>
      <textarea
        className="w-full p-2 border rounded mb-4"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        rows={4}
      />

      <div className="flex gap-2 mb-4">
        <button className="px-4 py-2 bg-blue-600 text-white rounded" onClick={run}>
          Run
        </button>
        <button
          className="px-4 py-2 bg-gray-200 rounded"
          onClick={() => {
            setInput("");
            setResult(null);
            setError(null);
          }}
        >
          Clear
        </button>
      </div>

      <div>
        <label className="block mb-2">Result</label>
        <pre className="p-3 border rounded bg-gray-50">
          {error ? `Error: ${error}` : JSON.stringify(result, null, 2)}
        </pre>
      </div>
    </div>
  );
}