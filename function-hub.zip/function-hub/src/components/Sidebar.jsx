import React from "react";

export default function Sidebar({ functions = [], onSelect }) {
  return (
    <aside className="w-64 bg-white border-r p-4">
      <div className="mb-4">
        <button
          className="p-2 rounded bg-gray-200"
          onClick={() => onSelect(null)}
        >
          ☰ Functions
        </button>
      </div>
      <ul>
        {functions.map((f) => (
          <li key={f.name} className="mb-2">
            <button
              className="w-full text-left p-2 hover:bg-gray-100 rounded"
              onClick={() => onSelect(f)}
            >
              {f.label || f.name}
            </button>
          </li>
        ))}
      </ul>
    </aside>
  );
}