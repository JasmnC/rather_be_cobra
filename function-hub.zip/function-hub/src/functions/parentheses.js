// def is_valid_parentheses(s: str) -> bool:
//     """
//     Check if a string has valid parentheses.
//     Args:
//         s (str): String containing only '(', ')', '{', '}', '[', ']'
//
//     Returns:
//         bool: True if parentheses are valid, False otherwise
//
//     Example:
//         >>> is_valid_parentheses("()")
//         True
//         >>> is_valid_parentheses("()[]{}")
//         True
//         >>> is_valid_parentheses("(]")
//         False
//     """
//     pass
export function is_valid_parentheses(s) {
  const stack = [];
  const pairs = { ")": "(", "]": "[", "}": "{" };

  for (const ch of s) {
    if (["(", "[", "{"].includes(ch)) stack.push(ch);
    else if (pairs[ch]) {
      if (stack.pop() !== pairs[ch]) return false;
    }
  }
  return stack.length === 0;
}