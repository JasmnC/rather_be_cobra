/**
 * Check if a string is a palindrome.
 *
 * @param {string} s - Input string to check.
 * @returns {boolean} True if palindrome, False otherwise.
 *
 * @example
 * isPalindrome("racecar"); // true
 * isPalindrome("A man a plan a canal Panama"); // true
 * isPalindrome("hello"); // false
 */
export function isPalindrome(s) {
  if (s == null) return false;
  const str = String(s).replace(/[^0-9a-z]/gi, "").toLowerCase();
  const rev = str.split("").reverse().join("");
  return str === rev;
}
