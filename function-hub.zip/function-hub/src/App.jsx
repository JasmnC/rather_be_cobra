import { useState } from "react";
import Sidebar from "./components/Sidebar";
import FunctionPanel from "./components/FunctionPanel";
import { isPalindrome } from "./functions/palindrome";
import { is_valid_parentheses } from "./functions/parentheses";

export default function App() {
  const [selectedFunc, setSelectedFunc] = useState(null);

  const functions = [
    { name: "palindrome", label: "Palindrome Checker", fn: isPalindrome },
    { name: "parentheses", label: "Valid Parentheses", fn: is_valid_parentheses }
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar functions={functions} onSelect={setSelectedFunc} />
      <main className="flex-1 p-6">
        <FunctionPanel selectedFunc={selectedFunc} />
      </main>
    </div>
  );
}